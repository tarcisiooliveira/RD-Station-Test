# Go

## Como rodar os testes

### Versão mínima
- Go 1.16

### Terminal

No terminal, execute os comandos:

```bash
cd go
go test
```
