package csbalancing

// Entity ...
type Entity struct {
	ID    int
	Score int
}

// CustomerSuccessBalancing ...
func CustomerSuccessBalancing(customerSuccess []Entity, customers []Entity, customerSuccessAway []int) int {
	// Write your solution here
	return 0
}
