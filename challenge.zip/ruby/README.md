# Ruby

## Como rodar os testes

No terminal, execute os comandos:

```
cd ruby
ruby customer_success_balancing.rb
```